package com.example.milestone;
//package com.example.fitmoji_avatar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

//import android.app.ActionBar;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;


public class ActivityAvatar extends AppCompatActivity {

    private ImageButton btn_none;
    private ImageButton btn_hat;
    private ImageButton btn_brim;
    private ImageView img_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avatar);

        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        img_view = (ImageView) findViewById(R.id.img_avatar);
        btn_brim = (ImageButton)findViewById(R.id.button_brim);
        btn_hat = (ImageButton)findViewById(R.id.button_hat);
        btn_none = (ImageButton)findViewById(R.id.button_none);

//        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getApplicationContext(), "Back Button Clicked", Toast.LENGTH_SHORT).show();
//            }
//        });

    }

    public void click_null(View view) {
        img_view.setImageResource(R.drawable.avatar_male);
    }

    public void click_hat(View view) {
        img_view.setImageResource(R.drawable.avatar_male_hat);
    }

    public void click_brim(View view) {
        img_view.setImageResource(R.drawable.avatar_male_brim);
    }

    public void click_fez(View view) {img_view.setImageResource(R.drawable.avatar_male_fez);
    }

    public void click_spectacles(View view) {
        img_view.setImageResource(R.drawable.avatar_male_spectacles);
    }

    public void click_unlock_facemask(View view) {
        //unlock if step is 50000 steps

        EditText setValue;
        setValue = (EditText) findViewById(R.id.step_unlock);
        String hardvalue = setValue.getText().toString();
        int actualvalue = Integer.parseInt(hardvalue);


        if (actualvalue == 50000) {
            img_view.setImageResource(R.drawable.avatar_male_facemask);
        }
        //img_view.setImageResources(R.drawable.avatar_male_facemask);
    }

    public void click_unlock_sunglasses(View view) {
        //unlock if step is 150000 steps

        EditText setValue;
        setValue = (EditText) findViewById(R.id.step_unlock);
        String hardvalue = setValue.getText().toString();
        int actualvalue = Integer.parseInt(hardvalue);
        if (actualvalue == 150000) {
            img_view.setImageResource(R.drawable.avatar_male_sunglasses);
        }
        //img_view.setImageResources(R.drawable.avatar_male_sunglasses);
    }
}