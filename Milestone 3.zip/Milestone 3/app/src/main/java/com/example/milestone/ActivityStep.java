package com.example.milestone;

import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.content.Context;

public class ActivityStep extends AppCompatActivity implements SensorEventListener {
    private TextView textViewStepCounter;
    private SensorManager mSensorManager;
    private Sensor mStepCounter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step);

        textViewStepCounter = (TextView) findViewById(R.id.textViewStepCounter);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        mStepCounter = mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        String sensor_error = getResources().getString(R.string.counter);

        if (mStepCounter == null) { textViewStepCounter.setText(sensor_error); }
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mStepCounter != null) {
            mSensorManager.registerListener(this, mStepCounter,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        int sensorType = sensorEvent.sensor.getType();
        int currentValue = (int) sensorEvent.values[0];

        switch (sensorType) {
            // Event came from the light sensor.
            case Sensor.TYPE_STEP_COUNTER:
                // Set the light sensor text view to the light sensor string
                // from the resources, with the placeholder filled in.
                textViewStepCounter.setText("Steps: {currentValue}");
                break;
            default:
                // do nothing
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

}