package com.example.milestone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class ActivityHome extends AppCompatActivity {


    //final int random = new Random().nextInt(5);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

    }


    @Override
    protected void onStart() {

        super.onStart();
        setQuote();
    }
    @Override
    protected void onResume() {

        super.onResume();
        setQuote();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_avatar:
                displayToast("Avatar");
                openAvatar();
                return true;
            case R.id.action_calorie:
                displayToast("Calorie");
                openCalorie();
                return true;
            case R.id.action_exercise:
                displayToast("Exercise");
                openExercise();
                return true;
            case R.id.action_step:
                displayToast("Step");
                openStep();
                return true;
            case R.id.action_water:
                displayToast("Water");
                openWater();
                return true;
            case R.id.action_logout:
                displayToast("Logout");
                goBack();
                return true;

            default:
                // Do nothing
        }
        return super.onOptionsItemSelected(item);
    }

    public void displayToast(String message) {
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
    }

    public void goBack() {
        Intent intent = new Intent(this, ActivityLogin.class);
        startActivity(intent);
    }

    public void openWater() {
        Intent intent = new Intent(this, ActivityWater.class);
        startActivity(intent);
    }
    private void openAvatar() {
        Intent intent = new Intent(this, ActivityAvatar.class);
        startActivity(intent);
    }
    private void openCalorie() {
        Intent intent = new Intent(this, ActivityCalorie.class);
        startActivity(intent);
    }
    private void openStep() {
        Intent intent = new Intent(this, ActivityStep.class);
        startActivity(intent);
    }
    private void openExercise() {
        Intent intent = new Intent(this, ActivityExercise.class);
        startActivity(intent);
    }

    public void waterOpen(View view) {
        openWater();
    }

    public void openStep(View view) {
        openStep();
    }

    public void openExercise(View view) {
        openExercise();
    }

    public void openCalorie(View view) {
         openCalorie();
    }

    public void avatarOpen(View view) {
        openAvatar();
    }

    public void setQuote() {
        TextView quote = (TextView) findViewById(R.id.quotes);
        int random = new Random().nextInt(5);

        switch(random) {
            case 0:
                quote.setText(R.string.quote1);
                break;
            case 1:
                quote.setText(R.string.quote2);
                break;
            case 2:
                quote.setText(R.string.quote3);
                break;
            case 3:
                quote.setText(R.string.quote4);
                break;
            case 4:
                quote.setText(R.string.quote5);
                break;
            default:
                quote.setText(R.string.quote1);
        }
    }
}