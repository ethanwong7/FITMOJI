package com.example.milestone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityWater extends AppCompatActivity {
    ImageView cup1,cup2,cup3,cup4,cup5,cup6,cup7,cup8;
    Button fill_cup,reset;
    Integer cupNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water);

        cupNum = 0;
        cup1 = (ImageView) findViewById(R.id.cup1) ;
        cup2 = (ImageView) findViewById(R.id.cup2);
        cup3 = (ImageView) findViewById(R.id.cup3);
        cup4 = (ImageView) findViewById(R.id.cup4);
        cup5 = (ImageView) findViewById(R.id.cup5);
        cup6 = (ImageView) findViewById(R.id.cup6);
        cup7 = (ImageView) findViewById(R.id.cup7);
        cup8 = (ImageView) findViewById(R.id.cup8);

        fill_cup = (Button) findViewById(R.id.fill_cup);
        fill_cup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cupNum == 0) {
                    cup1.setImageResource(R.drawable.cup_full);
                    Context context = getApplicationContext();
                    CharSequence text = "Cup Filled!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    cupNum += 1;
                    System.out.println(cupNum);
                } else if (cupNum == 1) {
                    cup2.setImageResource(R.drawable.cup_full);
                    Context context = getApplicationContext();
                    CharSequence text = "Cup Filled!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    cupNum += 1;
                    System.out.println(cupNum);
                }
                else if (cupNum == 2) {
                    cup3.setImageResource(R.drawable.cup_full);
                    Context context = getApplicationContext();
                    CharSequence text = "Cup Filled!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    cupNum += 1;
                    System.out.println(cupNum);
                }
                else if (cupNum == 3) {
                    cup4.setImageResource(R.drawable.cup_full);
                    Context context = getApplicationContext();
                    CharSequence text = "Cup Filled!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    cupNum += 1;
                    System.out.println(cupNum);
                }
                else if (cupNum == 4) {
                    cup5.setImageResource(R.drawable.cup_full);
                    Context context = getApplicationContext();
                    CharSequence text = "Cup Filled!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    cupNum += 1;
                    System.out.println(cupNum);
                }else if (cupNum == 5) {
                    cup6.setImageResource(R.drawable.cup_full);
                    Context context = getApplicationContext();
                    CharSequence text = "Cup Filled!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    cupNum += 1;
                    System.out.println(cupNum);
                }else if (cupNum == 6) {
                    cup7.setImageResource(R.drawable.cup_full);
                    Context context = getApplicationContext();
                    CharSequence text = "Cup Filled!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    cupNum += 1;
                    System.out.println(cupNum);
                }else if (cupNum == 7) {
                    cup8.setImageResource(R.drawable.cup_full);
                    Context context = getApplicationContext();
                    CharSequence text = "Cup Filled!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    cupNum += 1;
                    System.out.println(cupNum);
                }else if (cupNum >= 8){
                    Context context = getApplicationContext();
                    CharSequence text = "Goal testAchieved!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
            }
        });
    reset = (Button) findViewById(R.id.reset);
    reset.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            cup1.setImageResource(R.drawable.cup_empty);
            cup2.setImageResource(R.drawable.cup_empty);
            cup3.setImageResource(R.drawable.cup_empty);
            cup4.setImageResource(R.drawable.cup_empty);
            cup5.setImageResource(R.drawable.cup_empty);
            cup6.setImageResource(R.drawable.cup_empty);
            cup7.setImageResource(R.drawable.cup_empty);
            cup8.setImageResource(R.drawable.cup_empty);
            cupNum = 0;
        }
    });
        }
    }
